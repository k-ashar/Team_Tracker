// [1] Images: NbaLogo, freebiesupply.com, https://freebiesupply.com/logos/nba-logo/ 
// [2] Images: Team Logos, basketball-reference.com, https://www.basketball-reference.com/

// Data: basketball-reference.com, https://www.basketball-reference.com/
// Project Idea: I got the project idea through my passions of basketball

var nbaTeam = getColumn("NBA Teams", "Team");
var nbaTeamLocation = getColumn("NBA Teams", "Location");
var nbaTeamChampionshipWins = getColumn("NBA Teams", "Championship wins");
var nbaTeamLogo = getColumn("NBA Teams", "Image");
var nbaTeamConference = getColumn("NBA Teams", "Conference");
var nbaTeamDivision = getColumn("NBA Teams", "Division");
var nbaTeamArena = getColumn("NBA Teams", "Arena");
var nbaTeamArenaCapacity = getColumn("NBA Teams", "Arena capacity");
var nbaTeamYearJoined = getColumn("NBA Teams", "Year joined to the NBA");

setProperty("teamDropdown", "options", nbaTeam);

onEvent("StartButton", "click", function() {
  setScreen("ChooseTeam");
  showTeamLogo();
});

onEvent("nextButton", "click", function() {
  var selectedTeam = getText("teamDropdown");
  var filteredData = filterNbaTeamData(selectedTeam);
  if (filteredData) {
    setText("InformationHeading", filteredData.Team);
    setText("Information", 
      "Conference: " + filteredData.Conference +
      "\nDivision: " + filteredData.Division +
      "\nLocation: " + filteredData.Location +
      "\nArena: " + filteredData.Arena +
      "\nArena Capacity: " + filteredData["Arena capacity"] +
      "\nYear Joined: " + filteredData["Year joined to the NBA"] +
      "\nNumber of Championships: " + filteredData["Championship wins"]
    );
    if (filteredData.Image !== "") {
      setImageURL("teamLogoInfo", filteredData.Image); 
    } else {
      console.log("No image URL provided for " + filteredData.Team);
    }
    setScreen("InformationScreen");
  } else {
    console.log("Team data not found for selected team: " + selectedTeam);
  }
});

onEvent("LearnMore", "click", function() {
  setScreen("ChooseTeam");
});

onEvent("homeButton", "click", function() {
  setScreen("StartScreen");
});

onEvent("teamDropdown", "change", function() {
  showTeamLogo();
});

function filterNbaTeamData(selectedTeam) {
  for (var i = 0; i < nbaTeam.length; i++) {
    if (nbaTeam[i] === selectedTeam) {
      return {
        Team: nbaTeam[i],
        Location: nbaTeamLocation[i],
        "Championship wins": nbaTeamChampionshipWins[i],
        Image: nbaTeamLogo[i],
        Conference: nbaTeamConference[i],
        Division: nbaTeamDivision[i],
        Arena: nbaTeamArena[i],
        "Arena capacity": nbaTeamArenaCapacity[i],
        "Year joined to the NBA": nbaTeamYearJoined[i]
      };
    }
  }
  return null;
}

function showTeamLogo() {
  var selectedTeam = getText("teamDropdown");
  var filteredData = filterNbaTeamData(selectedTeam);
  if (filteredData && filteredData.Image !== "") {
    setImageURL("teamLogoSelect", filteredData.Image);
  }
}